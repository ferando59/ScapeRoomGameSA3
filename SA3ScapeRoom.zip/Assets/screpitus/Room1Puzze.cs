using UnityEngine;

public class Room1Puzze : MonoBehaviour
{
    
    private bool puzzDone = false;
    public puzzeCount PuzzeCount;
    public GameObject obj;

    void Start()
    {
        PuzzeCount = obj.GetComponent<puzzeCount>();
    }

    

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space)){

            puzzDone = true;
            

        }

        if(puzzDone == true){
            solvePuzz();
        }
    }

    void solvePuzz(){

        PuzzeCount.puzzJaFeitas += 1;
        puzzDone = false;

    }
}
